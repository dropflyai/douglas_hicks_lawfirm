import AdminControlCenter from '../../../components/admin/AdminControlCenter'

export default function AdminPortal() {
  return <AdminControlCenter />
}