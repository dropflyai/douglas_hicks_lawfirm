import AdvancedRolePortal from '../../../components/AdvancedRolePortal'

export default function AttorneyDashboard() {
  return <AdvancedRolePortal />
}